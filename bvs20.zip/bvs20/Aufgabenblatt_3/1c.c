#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

int pid;
if((pid = fork())==0){
printf("Hier ist der Sohn mit PID %d\n",getpid());
}
else{
printf("Hier ist der Vater\n");
printf("Mein Sohn hat die PID %d\n",pid);
}
}