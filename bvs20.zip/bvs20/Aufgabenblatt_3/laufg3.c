#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

	if(fork()==0){
	  
		for(int i=4;i<7;i++){
		printf("	%d \n",i);}

	for(int i=10;i<13;i++){
		printf("	%d \n",i);}

	for(int i=16;i<19;i++){
		printf("	%d \n",i);}
		
exit(0);}
	  
	
		for(int i=1;i<4;i++){
	printf("%d \n",i);
		sleep(1);
}
	
	for(int i=7;i<10;i++){
		printf("%d \n",i);
		sleep(1);
}

	for(int i=13;i<16;i++){
		printf("%d \n",i);
		sleep(1);
}
				
}