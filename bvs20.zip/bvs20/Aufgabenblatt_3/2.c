#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

/* Die Funktion sighand() ist ein "Signalhandler", der
   ausgefuehrt wird, wenn bei einem Prozess ein bestimmtes
   Signal eintrifft. Dazu muss die Funktion zuvor durch
   einen sigaction()-Aufruf an dieses Signal "gebunden" werden,
   also fuer diesen Prozess und dieses Signal registriert
   werden (siehe Hauptprogramm).
   Trifft ein Signal ein, an das der Prozess keinen Signal-
   handler gebunden hat, so wird der Prozess durch das Signal
   terminiert ("abgeschossen"). */
   
void sighand() {  //Signalhandle, wird ausgef�hrt wenn Signal beim Prozess ankommt

 /* Testausgabe */
 printf("Signal eingetroffen\n\n");

}

/* Hauptprogramm */

int main() {

  int sohn_pid;

  /* Bindung des Signalhandlers an das Signal SIGUSR1.
     SIGUSR1 ist ein Signal, was Programmierer frei benutzen
     koennen; die meisten anderen Signale werden vom BS-Kern
     verwendet. */

  struct sigaction sigact;   //erzeuge Datentyp zur Signalverarbeitung

  sigact.sa_handler = sighand;  //setze den Handler auf sighand
  sigemptyset(&sigact.sa_mask);  //erzeugt eine leere Signalmaske
  sigact.sa_flags = 0;		// setzte flags auf 0

  sigaction(SIGUSR1,&sigact,NULL); // Sigaction wird in Signaltabelle eingetragen unter SIGUSR1
  sigaction(SIGUSR2,&sigact,NULL); // dazu

  printf("\n");

  if ((sohn_pid=fork())==0 ) {

    printf("Sohn wartet auf Signal.\n\n");
    pause(); /* Sohn wartet auf Signal */
    printf("Sohn laeuft weiter.\n\n");
    printf("Sohn wartet nochmals auf Signal.\n\n");
    pause();
    printf("Sohn laeuft zuende.\n\n");
    exit(0);

  }

  printf("Vater tut etwas anderes.\n\n");

  sleep(2);  /* Vater wartet zwei Sekunden */

  printf("Vater schickt Signal an Sohn.\n\n");
  kill(sohn_pid,SIGUSR1); /* Signal an Sohn */

  sleep(2);  /* Vater wartet nochmals zwei Sekunden */

  printf("Vater schickt nochmals Signal an Sohn.\n\n");
  kill(sohn_pid,SIGUSR2);	//ge�ndert

}