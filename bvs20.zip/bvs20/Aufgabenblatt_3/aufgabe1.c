#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

    int pid;
    if((pid = fork())== 0){
        printf("Hier ist der Sohn mit PID %d\n", getpid());
        exit(0);
    }
    printf("Hier ist der Vater\n");
    printf("Mein Sohn hat die PID %d\n", pid);
}

/*
    In C der Vergleichoperator == ist st�rker als der Zuweisungsoperator =.
    Die Variable pid bekommt das Ergebnis der Vergleichsoperation, aber nicht
    die PID des Sohnprozesses
*/
