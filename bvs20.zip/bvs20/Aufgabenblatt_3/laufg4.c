#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void sighand(){
printf("Signal angekommen.\n");
}

int main(){
int sohn_pid;

	  struct sigaction sigact;

  sigact.sa_handler = sighand;
  sigemptyset(&sigact.sa_mask);
  sigact.sa_flags = 0;

sigaction(SIGUSR1,&sigact,NULL);
//sigaction(SIGUSR2,&sigact,NULL);
//sigaction(SIGUSR3,&sigact,NULL);

	if((sohn_pid = fork())==0){
	pause();
		for(int i=4;i<7;i++){
		printf("	%d \n",i);}
	kill(getppid(),SIGUSR1);

pause();
	for(int i=10;i<13;i++){
		printf("	%d \n",i);}
	kill(getppid(),SIGUSR1);

pause();
	for(int i=16;i<19;i++){
		printf("	%d \n",i);}
		
exit(0);}


	for(int i=1;i<4;i++){
	printf("%d \n",i);
		sleep(1);
}
	kill(sohn_pid,SIGUSR1);
pause();
	for(int i=7;i<10;i++){
		printf("%d \n",i);
		sleep(1);
} 	
	kill(sohn_pid,SIGUSR1);
pause();	
for(int i=13;i<16;i++){
		printf("%d \n",i);
		sleep(1);
}
	kill(sohn_pid,SIGUSR1);				
}