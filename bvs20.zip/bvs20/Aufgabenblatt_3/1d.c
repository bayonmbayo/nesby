#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

    int status;
    int sohn_pid;
    if((sohn_pid = fork()) == 0){
        
        int status1;
        int sohn_pid1;

        if((sohn_pid1 = fork()) == 0){
            printf("Sohn1 : Eigene PID ist %d \n", getpid());
            //printf("Sohn1 : Eigene PID ist %d\n", getppid());
            exit(0);
        }

        else {
            printf("Vater1: Ich warte auf den Sohn1 \n");
            wait(&status1);
            printf("Vater1 : Eigene PID ist %d \n", getpid());
            //printf("Vater1 : Sohn-PID ist %d \n", sohn_pid1);
        }

        exit(0);
    }
        else{
        printf("Vater: Ich warte auf den Vater1 \n");
        wait(&status);
        printf("Vater : Eigene PID ist %d \n", getpid());
        //printf("Vater : Sohn-PID ist %d \n", sohn_pid);


    }

}
