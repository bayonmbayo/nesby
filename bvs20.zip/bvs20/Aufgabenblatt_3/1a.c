#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

	if(fork()==0){
	  printf("Hier ist der Sohn\n");
		exit(0);}
	  printf("Hier ist der Vater\n");
}




