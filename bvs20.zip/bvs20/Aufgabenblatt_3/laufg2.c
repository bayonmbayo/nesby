#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/resource.h>

int main(){

    int pid1, pid2;
int c; int d;
	int a = 1000, b = 5; 
	printf("Prioritaet?\n");
	scanf("%d",&c);

	if((pid1 =fork())== 0){
        printf("Der Sohn hat PID1 %d\n", getpid());
        while(1){
			d = a / b;
		}
exit(0);    
}
	
	if((pid2=fork())==0){
		printf("Der Sohn hat PID2 %d\n", getpid());
		while(1){
			d = a / b;}
exit(0);		
}
		printf("PID vom Sohn1 %d\n",pid1);
		printf("PID vom Sohn2 %d\n",pid2);
		setpriority(PRIO_PROCESS,pid2,c);

for(int i=0;i<10;i++){

sleep(1);
system("date");
system("ps -l");
}
kill(pid1,SIGKILL);
kill(pid2,SIGKILL);
}
