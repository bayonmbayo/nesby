#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(){

    int pid;
	if(fork()== 0){
        printf("Hier ist der Sohn\n");
        exit(0);
    }
    printf("Hier ist der Vater\n");
}

/*
    fork ist undefiniert, er terminiert nicht richtig den Sohnprozess

*/
