#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int main(int argc, char** argv) {

    int i = 1;
    int sohn_pid;
    int status;
    
    if((sohn_pid = fork()) == 0){
        
        printf("Sohn: Ich schlafe jetzt\n");
        printf("Sohn: Eigene PID ist: %d\n", getpid());
        printf("Sohn: Vater PID ist: %d\n", getppid());
        sleep(10);
        printf("Sohn: Ich bin jetzt fertig\n");
        exit(0);
    }
    
    printf("Vater: Ich warte auf den Sohn\n");
    wait(&status);
    printf("Vater: Sohn ist jetzt fertig\n");
    printf("Sohnpid = %d\n", sohn_pid);
    printf("Vater: Rueckgabestatus = %d\n", status);
}
