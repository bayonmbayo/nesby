#include <stdio.h>
#include <stdlib.h>



int main(int argc, char** argv) {



	
    for(int i=0;i<400000;i++){
	
	printf("i = %d\n", i);
	
    }
    
    
    
}