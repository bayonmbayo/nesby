#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>


int main(int argc, char** argv) {

    int sohn_pid;
    
    if((sohn_pid = fork()) == 0){
        execv("fork2a", NULL);
        
    }
    sleep(10);			
    kill(sohn_pid, SIGKILL);
    
}