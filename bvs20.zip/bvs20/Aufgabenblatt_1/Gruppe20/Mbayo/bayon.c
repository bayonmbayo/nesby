#include<stdlib.h>
#include<string.h>

main(){

	printf("Hallo Welt\n");
}
