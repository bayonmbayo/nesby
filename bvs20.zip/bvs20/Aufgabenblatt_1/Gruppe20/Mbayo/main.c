#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/wait.h>


int main()
{
    int semid;
    unsigned short init_array[1];
    struct sembuf sem_p, sem_v;
    int status;

    semid = semget(IPC_PRIVATE,1,IPC_CREAT|0777);
    init_array[0] = 0;
    semctl(semid,0,SETALL,init_array);

    sem_p.sem_num = 0;          sem_v.sem_num = 0;
    sem_p.sem_op = -1;          sem_v.sem_op = 1;
    sem_p.sem_flg = 0;          sem_v.sem_flg = 0;

    if(fork()== 0){
        printf("Ich bin der VORgaenger\n");
        sleep(10);
        semop(semid,&sem_v,1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid,&sem_p,1);
        printf("Ich bin der NACHgaenger\n");
        exit(0);
    }

    wait(&status);
    wait(&status);

    //semctl(semid,0,IPC_RMID,0);
}
