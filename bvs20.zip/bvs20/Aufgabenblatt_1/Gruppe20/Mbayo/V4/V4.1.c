/******************************************/
/*                                        */
/*  Prof. Dr. Carsten Vogt                */
/*  Fachhochschule Koeln                  */
/*  Fakultaet 07, Nachrichtentechnik      */
/*  http://www.nt.fh-koeln.de/vogt        */
/*                                        */
/*  UNIX-C-Schnittstelle:                 */
/*  Synchronisation mit Semaphoren        */
/*  Hier: Reihenfolgebeziehung            */
/*                                        */
/******************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/sem.h>

main() {
 /* Vater bereitet vor */
 int status; /* Hilfsvariable */
 int semid; /* Identifikator der Semaphorgruppe */
 unsigned short init_array[2]; /* zur Initialisierung */
 struct sembuf sem_p[2], sem_v[2]; /* Beschreibung von P- und V-Operationen */

 /* Erzeugung einer Semaphorgruppe mit zwei Semaphoren */
 semid = semget(IPC_PRIVATE,2,IPC_CREAT|0777);

 /* Initialisierung des Semaphors mit dem Wert 0 */
 init_array[0] = init_array[1] = 0;
 semctl(semid,0,SETALL,init_array);

 /* Vorbereitung der P- und der V-Operation */
 sem_p[0].sem_num = 0;   sem_v[0].sem_num = 0;
 sem_p[0].sem_op  = -1;  sem_v[0].sem_op  = 1;
 sem_p[0].sem_flg = 0;   sem_v[0].sem_flg = 0;

 sem_p[1].sem_num = 1;   sem_v[1].sem_num = 1;
 sem_p[1].sem_op  = -1;  sem_v[1].sem_op  = 1;
 sem_p[1].sem_flg = 0;   sem_v[1].sem_flg = 0;

 if (fork()==0) {
  /* Sohn 1 */
  
  sleep(2);
  
  printf("\nerster Sohn\n");

  /* Entblockiert den Nachfolger durch eine V-Operation */
  semop(semid,&sem_v[0],1);

  exit(0);
 }

 if (fork()==0) {
  /* Sohn 2 */
  
  /* Blockiert in einer P-Operation und wartet damit auf den Vorgaenger */

  sleep(1);
  semop(semid,&sem_p[0],1);

  printf("\nzweiter Sohn\n");
  semop(semid,&sem_v[1],1);

  exit(0);
 }

if (fork()==0) {
  /* Sohn 3 */
  
  semop(semid,&sem_p[1],1);
  printf("\ndritter Sohn\n");
  
  exit(0);
 }
 
 /* Vater wartet auf Ende der beiden Soehne */
 wait(&status);
 wait(&status);
 wait(&status);
 
 /* Vater loescht den Semaphor */
 semctl(semid,0,IPC_RMID,0);
}
