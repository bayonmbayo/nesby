#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/wait.h>


int main()
{
    int semid;
    unsigned short init_array[4];
    struct sembuf sem_p[4];
    struct sembuf sem_v[4];
    int status;
    semid = semget(IPC_PRIVATE,4,IPC_CREAT|0777);

    for(int i = 0; i<4; i++){
        init_array[i] = 0;
    }
    semctl(semid,0,SETALL,init_array);

    sem_p[0].sem_num = 0;       sem_v[0].sem_num = 0;
    sem_p[1].sem_num = 1;       sem_v[1].sem_num = 1;
    sem_p[2].sem_num = 2;       sem_v[2].sem_num = 2;
    sem_p[3].sem_num = 3;       sem_v[3].sem_num = 3;

    for(int i = 0; i<4; i++){
       sem_p[i].sem_op = -1;

    }
    for(int i = 0; i<4; i++){
        sem_v[i].sem_op = 1;
    }
    for(int i = 0; i<4; i++){
        sem_p[i].sem_flg = 0;
    }

    for(int i = 0; i<4; i++){
        sem_v[i].sem_flg = 0;
    }

    if(fork()== 0){
        printf("Ich gehe durch die Tuer 1\n");
        sleep(5);
        semop(semid,&sem_v[0],1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid,&sem_p[0],1);
        printf("Ich gehe durch die Tuer 2\n");
        sleep(5);
        semop(semid,&sem_v[1],1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid,&sem_p[1],1);
        printf("Ich gehe durch die Tuer 3\n");
        sleep(5);
        semop(semid,&sem_v[2],1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid,&sem_p[2],1);
        printf("Ich gehe durch die Tuer 4\n");
        sleep(5);
        exit(0);
    }

    wait(&status);
    wait(&status);
    wait(&status);
    wait(&status);

    semctl(semid,0,IPC_RMID,0);
}
