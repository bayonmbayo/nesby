#include <stdio.h>
#include <stdlib.h>
#include <sys/sem.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/wait.h>


int main()
{
    int semid1,semid2;
    unsigned short init_array[4];
    struct sembuf sem_p1[4];
    struct sembuf sem_v1[4];
    struct sembuf sem_p2[4];
    struct sembuf sem_v2[4];
    int status;
    semid1 = semget(IPC_PRIVATE,4,IPC_CREAT|0777);
    semid2 = semget(IPC_PRIVATE,4,IPC_CREAT|0777);
    for(int i = 0; i<4; i++){
        init_array[i] = 0;
    }
    semctl(semid1,0,SETALL,init_array);
    semctl(semid2,0,SETALL,init_array);

    sem_p1[0].sem_num = 0;       sem_v1[0].sem_num = 0;
    sem_p1[1].sem_num = 1;       sem_v1[1].sem_num = 1;
    sem_p1[2].sem_num = 2;       sem_v1[2].sem_num = 2;
    sem_p1[3].sem_num = 3;       sem_v1[3].sem_num = 3;

    for(int i = 0; i<4; i++){
       sem_p1[i].sem_op = -1;

    }
    for(int i = 0; i<4; i++){
        sem_v1[i].sem_op = 1;
    }
    for(int i = 0; i<4; i++){
        sem_p1[i].sem_flg = 0;
    }

    for(int i = 0; i<4; i++){
        sem_v1[i].sem_flg = 0;
    }
    
    sem_p2[0].sem_num = 0;       sem_v2[0].sem_num = 0;
    sem_p2[1].sem_num = 1;       sem_v2[1].sem_num = 1;
    sem_p2[2].sem_num = 2;       sem_v2[2].sem_num = 2;
    sem_p2[3].sem_num = 3;       sem_v2[3].sem_num = 3;

    for(int i = 0; i<4; i++){
       sem_p2[i].sem_op = -1;

    }
    for(int i = 0; i<4; i++){
        sem_v2[i].sem_op = 1;
    }
    for(int i = 0; i<4; i++){
        sem_p2[i].sem_flg = 0;
    }

    for(int i = 0; i<4; i++){
        sem_v2[i].sem_flg = 0;
    }

    if(fork()== 0){
        printf("Ich gehe durch die Tuer 1\n");
        sleep(5);
        semop(semid1,&sem_v1[0],1);
        semop(semid2,&sem_p2[2],1);
        printf("Ich gehe durch die Tuer 1 zurueck\n");
        sleep(5);
        printf("Ich bin zurueck wieder da\n");
        sleep(10);
        exit(0);
    }

    if(fork()== 0){
        semop(semid1,&sem_p1[0],1);
        printf("Ich gehe durch die Tuer 2\n");
        sleep(5);
        semop(semid1,&sem_v1[1],1);
        semop(semid2,&sem_p2[1],1);
        printf("Ich gehe durch die Tuer 2 zurueck\n");
        sleep(5);
        semop(semid2,&sem_v2[2],1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid1,&sem_p1[1],1);
        printf("Ich gehe durch die Tuer 3\n");
        sleep(5);
        semop(semid1,&sem_v1[2],1);
        semop(semid2,&sem_p2[0],1);
        printf("Ich gehe durch die Tuer 3 zurueck\n");
        sleep(5);
        semop(semid2,&sem_v2[1],1);
        exit(0);
    }

    if(fork()== 0){
        semop(semid1,&sem_p1[2],1);
        printf("Ich gehe durch die Tuer 4\n");
        sleep(5);
        printf("Ich bin angekommen\n");
        sleep(10);
        printf("Ich gehe durch die Tuer 4 zurueck\n");
        sleep(5);
        semop(semid2,&sem_v2[0],1);
        exit(0);
    }

    wait(&status);
    wait(&status);
    wait(&status);
    wait(&status);

    semctl(semid1,0,IPC_RMID,0);
    semctl(semid2,0,IPC_RMID,0);
}