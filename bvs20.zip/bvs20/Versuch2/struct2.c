#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include<stdio.h>


	struct meinStruktTyp {
		
		char einZeichen;
		long wert;
	
	};
	
	void zuweisung1(struct meinStruktTyp st){
		
			st.einZeichen = '#';
			st.wert = 55555;
		

	
	}
	
		void zuweisung2(struct meinStruktTyp *stp){
		
			stp->einZeichen = '#';
			stp->wert = 55555;	
			

	
	}


int main(){



	
	struct meinStruktTyp name1;
	struct meinStruktTyp name2;
	

	

	
	zuweisung1(name1);
	zuweisung2(&name2);
	
	printf("Für ein Zeichnen von name1 : %c\n", name1.einZeichen);
	printf("Für ein long-Wert von name1 : %d\n", name1.wert);

	printf("Für ein Zeichnen von name1:  %c\n", name2.einZeichen);
	printf("Für ein long-Wert von name1:  %d\n", name2.wert);


}