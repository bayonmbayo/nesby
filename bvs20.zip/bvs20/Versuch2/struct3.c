#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include<stdio.h>


	int f1(){
		int a, b;
		f2();
		printf("%p %p \n", &a,&b);

	}	

	int f2(){
		int c,d;
		f3();
			printf("%p %p \n", &c,&d);
	}

	int f3(){
		int e, f;
			printf("%p %p \n", &e,&f);
	}



int main(){

	float *bereichsanfang;
	float *bereichsanfang2;
	float *bereichsanfang3;
	
	
	bereichsanfang = (float *) malloc (10 * sizeof(float));
	
	bereichsanfang2 = (float *) malloc (10 * sizeof(float));
	
	bereichsanfang3 = (float *) malloc (10 * sizeof(float));
	
	
	printf("%p %p %p \n", bereichsanfang,bereichsanfang2,bereichsanfang3);

	f1();
	
	
}