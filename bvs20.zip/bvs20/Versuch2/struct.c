#include <string.h>
#include <malloc.h>
#include <stdlib.h>
#include<stdio.h>

int main(){


	struct meinStruktTyp {
		
		char einZeichen;
		long wert;
	
	};
	
	struct meinStruktTyp name;
	
	int a = sizeof(char);
	int b = sizeof(long);
	int c = sizeof(name);
	
	printf("for char: %d\n", a);
	printf("for long: %d\n", b);
	printf("for meinStruktTyp: %d\n", c);


}
