#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <semaphore.h>

int main() {

 /* Vater bereitet vor */

 int status; /* Hilfsvariable f�r Signale */					//

 int semid; /* Identifikator der Semaphorgruppe */
 unsigned short init_array[2]; /* zur Initialisierung */

 struct sembuf sem_p, sem_v; /* Beschreibung von P- und V-Operationen */
 struct sembuf sem_p1, sem_v1; 

 int sohn_pid;
 /* Erzeugung einer Semaphorgruppe mit einem Semaphor */

 semid = semget(IPC_PRIVATE,2,IPC_CREAT|0777);

/* Initialisierung des Semaphors mit dem Wert 0 */

 init_array[0] = 0;
 init_array[1] = 0;         ///
 semctl(semid,0,SETALL,init_array);

 /* Vorbereitung der P- und der V-Operation */

 sem_p.sem_num = 0;   sem_v.sem_num = 0;
 sem_p.sem_op  = -1;  sem_v.sem_op  = 1;
 sem_p.sem_flg = 0;   sem_v.sem_flg = 0;

 sem_p1.sem_num = 1;   sem_v1.sem_num = 1;	//index vom Array 
 sem_p1.sem_op  = -1;  sem_v1.sem_op  = 1;	//standard
 sem_p1.sem_flg = 0;   sem_v1.sem_flg = 0;	//standard

	if((sohn_pid = fork())==0){
	semop(semid,&sem_p,1);
		for(int i=4;i<7;i++){
		printf("	%d \n",i);}
	

        semop(semid,&sem_v1,1);
	semop(semid,&sem_p,1);
	for(int i=10;i<13;i++){
		printf("	%d \n",i);}
	semop(semid,&sem_v1,1);

	semop(semid,&sem_p,1);
	for(int i=16;i<19;i++){
		printf("	%d \n",i);}
	semop(semid,&sem_v1,1);		
exit(0);}


	for(int i=1;i<4;i++){
	printf("%d \n",i);
		sleep(1);
}
	semop(semid,&sem_v,1);
	
	semop(semid,&sem_p1,1);
	for(int i=7;i<10;i++){
		printf("%d \n",i);
		sleep(1);
} 	
	semop(semid,&sem_v,1);
	semop(semid,&sem_p1,1);	
for(int i=13;i<16;i++){
		printf("%d \n",i);
		sleep(1);
}
	semop(semid,&sem_v,1);		
 semctl(semid,0,IPC_RMID,0);		
}
//semop(semid,&sem_v1,1);  
//semop(semid,&sem_p1,1);
//semop(semid,&sem_v,1);
//semop(semid,&sem_p,1);