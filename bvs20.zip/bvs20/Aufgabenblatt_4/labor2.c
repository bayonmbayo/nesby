#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <semaphore.h>

int main() {

 /* Vater bereitet vor */

 int status; /* Hilfsvariable f�r Signale */					//

 int semid; /* Identifikator der Semaphorgruppe */
 unsigned short init_array[2]; /* zur Initialisierung */

 struct sembuf sem_p, sem_v; /* Beschreibung von P- und V-Operationen */
 struct sembuf sem_p1, sem_v1; 

 int p1,p2,p3;
 /* Erzeugung einer Semaphorgruppe mit einem Semaphor */

 semid = semget(IPC_PRIVATE,2,IPC_CREAT|0777);

/* Initialisierung des Semaphors mit dem Wert 0 */

 init_array[0] = 1;
 //init_array[1] = 0;         //
 semctl(semid,0,SETALL,init_array);

 /* Vorbereitung der P- und der V-Operation */

 sem_p.sem_num = 0;   sem_v.sem_num = 0;
 sem_p.sem_op  = -1;  sem_v.sem_op  = 1;
 sem_p.sem_flg = 0;   sem_v.sem_flg = 0;

// sem_p1.sem_num = 1;   sem_v1.sem_num = 1;	//index vom Array 
 //sem_p1.sem_op  = -1;  sem_v1.sem_op  = 1;	//standard
 //sem_p1.sem_flg = 0;   sem_v1.sem_flg = 0;	//standard




//semop(semid,&sem_p,1);				//



 if ((p1 = fork())==0) {   /* Child A code */			//

while(1){
	semop(semid,&sem_p,1);
	printf("Sohn P1 belegt BM\n");
	sleep(2);
	printf("Sohn P1 gibt BM frei BM\n");
	semop(semid,&sem_v,1);
 	}

exit(0);

 } 
    
 if ((p2 = fork())==0) {		/* Child B */			//
while(1){
	semop(semid,&sem_p,1);
	printf("Sohn P2 belegt BM\n");
	sleep(2);
	printf("Sohn P2 gibt BM frei BM\n");
	semop(semid,&sem_v,1);
} 	
exit(0);



}	
if ((p3 = fork())==0) {		/* Child C */			//
while(1){
	semop(semid,&sem_p,1);
	printf("Sohn P3 belegt BM\n");
	sleep(2);
	printf("Sohn P3 gibt BM frei BM\n");
	semop(semid,&sem_v,1);	
} 	
exit(0);
}	

//Vater

//semop(semid,&sem_p1,1);

//semop(semid,&sem_v1,1);
	sleep(15);

kill(p1,SIGKILL);
kill(p2,SIGKILL);
kill(p3,SIGKILL);

 /* Vater loescht den Semaphor */

 semctl(semid,0,IPC_RMID,0);
 }

