#include<stdio.h>
#include<malloc.h>
#include<string.h>

int main(){
struct angestellteninfo{
char name[12];
int personalnummer;
float gehalt;
};

int groesse;
printf("Wie groß soll der Speicherbereich sein?");
scanf("%d",&groesse);

struct angestellteninfo *bereichsanfang;
bereichsanfang = (struct angestellteninfo *) malloc(groesse*sizeof(struct angestellteninfo));

for(int i = 0;i<groesse;i++){
strcpy(bereichsanfang[i].name,"Standardname");
bereichsanfang[i].personalnummer = 4711;
bereichsanfang[i].gehalt = 451.00;
}

for(int i = 0;i<groesse;i++){
printf("%s %d %.2f\n",bereichsanfang[i].name,bereichsanfang[i].personalnummer,bereichsanfang[i].gehalt);
}
}
