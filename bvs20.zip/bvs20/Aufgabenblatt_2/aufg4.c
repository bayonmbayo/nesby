﻿#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {

    
    struct angestellteninfo {
        char name[12];
        int perosonalnummer;
        float gehalt;
    };
    
    typedef struct angestellteninfo angestellteninfo;
    
    angestellteninfo *bereichsanfang; 
    
    bereichsanfang = (angestellteninfo*) malloc (10*sizeof(angestellteninfo));
    
    strcpy(bereichsanfang[0].name,"Bayon");
    bereichsanfang[0].perosonalnummer = 4711;
    bereichsanfang[0].gehalt = 300.00;
    
    strcpy(bereichsanfang[1].name,"Caro");
    bereichsanfang[1].perosonalnummer = 5611;
    bereichsanfang[1].gehalt = 800.00;
    
    strcpy(bereichsanfang[1].name,"Carine");
    bereichsanfang[1].perosonalnummer = 8933;
    bereichsanfang[1].gehalt = 1000.00;
    
    strcpy(bereichsanfang[2].name,"Marc");
    bereichsanfang[2].perosonalnummer = 8812;
    bereichsanfang[2].gehalt = 5000.00;
    
    strcpy(bereichsanfang[3].name,"Delphin");
    bereichsanfang[3].perosonalnummer = 5401;
    bereichsanfang[3].gehalt = 3000.00;
    
    strcpy(bereichsanfang[4].name,"Viviane");
    bereichsanfang[4].perosonalnummer = 5329;
    bereichsanfang[4].gehalt = 10000.00;
    
    strcpy(bereichsanfang[5].name,"Christian");
    bereichsanfang[5].perosonalnummer = 7633;
    bereichsanfang[5].gehalt = 5400.00;
    
    strcpy(bereichsanfang[6].name,"Sandra");
    bereichsanfang[6].perosonalnummer = 4444;
    bereichsanfang[6].gehalt = 4300.00;
    
    strcpy(bereichsanfang[7].name,"Lucain");
    bereichsanfang[7].perosonalnummer = 8943;
    bereichsanfang[7].gehalt = 8000.00;
    
    strcpy(bereichsanfang[8].name,"Olive");
    bereichsanfang[8].perosonalnummer = 7480;
    bereichsanfang[8].gehalt = 7400.00;
    
    strcpy(bereichsanfang[9].name,"Kainlive");
    bereichsanfang[9].perosonalnummer = 8745;
    bereichsanfang[9].gehalt = 450.00;
    
    for(int i = 0; i<10; i++){
            printf("Der Angestellte %s mit personalnummer %d kriegt %.2f pro Monat\n", 
                    bereichsanfang[i].name,bereichsanfang[i].perosonalnummer, bereichsanfang[i].gehalt);
        
    }
    
    
    
}