#include<string.h>
#include<stdio.h>

int main(){

struct angestellteninfo{
char name[12];
int personalnummer;
float gehalt;
};
typedef struct angestellteninfo angestellteninfo;

angestellteninfo* infoptr;
angestellteninfo info1;

infoptr = &info1;

strcpy(info1.name,"Schmitz");
info1.personalnummer = 4711;
info1.gehalt = 450.00; 

printf("%s %d %.2f\n",infoptr->name,infoptr->personalnummer,infoptr->gehalt);
}
