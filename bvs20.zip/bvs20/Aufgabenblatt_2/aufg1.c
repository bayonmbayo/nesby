#include<string.h>
#include<stdio.h>

int main(){
int array[10];
int i = 0;
int j = 0;

while(i<=20){
	if(i%2!=0){
		array[j++] = i;
}
	i++;
}

for(int k = 0; k<=9;k++){
printf("Element  %d  : %d\n",k,array[k]);
}
}
