#include<string.h>
#include<stdio.h>

int main(){
struct angestellteninfo{
char name[12];
int personalnummer;
float gehalt;
};

struct angestellteninfo info1, info2;

strcpy(info1.name,"Schmitz");
info1.personalnummer = 4711;
info1.gehalt = 450.00; 

info2 = info1;

printf("%s %d %.2f\n",info1.name,info1.personalnummer,info1.gehalt);  

printf("Der Angestellte %s hat die PErsonalnummer %d und kriegt %.2f als Gehalt\n", info1.name,info1.personalnummer,info1.gehalt);
printf("Der Angestellte %s hat die PErsonalnummer %d und kriegt %.2f als Gehalt mit info2 als Variable.\n",info2.name,info2.personalnummer,info2.gehalt);
}
