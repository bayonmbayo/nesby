﻿#include<string.h>
#include<stdio.h>

int main(){


struct angestellteninfo {
	int personalnummer;
	float gehalt;
};

typedef struct angestellteninfo angestellteninfo;

angestellteninfo* infoptr1;
angestellteninfo info1;

infoptr1 = &info1;

strcpy(info1.name,"Bayon");
info1.personalnummer = 4711;
info1.gehalt = 451.00;

printf("Der Angestellte %s hat die Personalnummer %d und kriegt %.2f als Gehalt\n",infoptr1->name,infoptr1->personalnummer,infoptr1->gehalt);

}
