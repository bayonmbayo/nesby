﻿#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main(){


struct angestellteninfo {
	char name[12];
	int personalnummer;
	float gehalt;
};

typedef struct angestellteninfo angestellteninfo;

angestellteninfo *info1 ;

info1 = (angestellteninfo *) malloc (sizeof(angestellteninfo));

strcpy(info1->name,"Bayon");
info1->personalnummer = 4711;
info1->gehalt = 451.00;
	
printf("Der Angestellte %s hat die Personalnummer %d und kriegt %.2f als Gehalt\n",info1->name,info1->personalnummer,info1->gehalt);

}
