#include <stdio.h>
#include <string.h>

int main(){
int array[20];
for (int i=1;i<=20;i++){
array[i-1]=i;
}
for (int k=0;k<=19;k++){
if (array[k]%2!=0){
printf("Element %d : %d\n",k,array[k]);
}
}
}
