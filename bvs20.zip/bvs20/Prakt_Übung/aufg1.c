#include<stdio.h>
#include<string.h>
#include<stdlib.h>


main(){

int status;

if (fork()==0){
	sleep(10);
	printf("Sohn sagt: Hallo Papa\n");
	sleep(5);
	exit(0);
}

else{
	printf("Ich warte auf den Sohn\n");
	wait(&status);
	printf("Papa sagt: Hallo Sohn\n");
}
}	