#include <fcntl.h>
#include <stdio.h>
#include <string.h>
main(){
int fd;
char dateiname[20],text[20];
printf("Dateiname: ");
scanf("%s",dateiname);
printf("Ausgabetext: ");
scanf("%s",text);
fd = open (dateiname,O_CREAT|O_WRONLY,0600);
write(fd,"\n",1);
write(fd,text,strlen(text));
write(fd,"\n\n",2);
close(fd);
}
