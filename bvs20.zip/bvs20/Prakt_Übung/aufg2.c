#include<stdio.h>
#include<string.h>
#include<signal.h>
#include<stdlib.h>


main(){

int sohn_pid;
int i = 0;
if ((sohn_pid=fork())==0){
	while(1) printf("Sohn: %d\n",i++);
	
}

else{
	sleep(5);
	kill(sohn_pid,SIGKILL);
	
}
}