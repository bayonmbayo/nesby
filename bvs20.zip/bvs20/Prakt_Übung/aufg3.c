#include<stdio.h>
#include<string.h>
#include<signal.h>
#include<stdlib.h>
#include<unistd.h>


main(){

	
	int err, status;
	if(fork() == 0){
		err = execv("programm", 0);
		exit(err);
	}
	sleep(5);
	kill(programm.c,SIGKILL);
	wait(&status);
	printf("Vater: R�ckgabestatus = %d\n", status);
}