#include<stdio.h>
#include<string.h>
#include<signal.h>
#include<stdlib.h>


main(){

	int i = 0;
	while(1) printf("Sohn: %d\n",i++);
	
}
